package id.az.statusjernih

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.exifinterface.media.ExifInterface
import com.otaliastudios.transcoder.Transcoder
import com.otaliastudios.transcoder.TranscoderListener
import com.otaliastudios.transcoder.strategy.DefaultAudioStrategy
import com.otaliastudios.transcoder.strategy.DefaultVideoStrategy
import com.otaliastudios.transcoder.source.ClipDataSource
import com.otaliastudios.transcoder.source.UriDataSource
import com.otaliastudios.transcoder.resize.AtMostResizer
import java.io.File
import java.text.DecimalFormat
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private val bg = 0xFF0B0D14.toInt()
    private val surface = 0xFF151925.toInt()
    private val card = 0xFF191F2D.toInt()
    private val white = 0xFFF4F5FA.toInt()
    private val muted = 0xFF9EA5B8.toInt()
    private val accent = 0xFF8B7CFF.toInt()
    private val mint = 0xFF7DE3C0.toInt()

    private var selectedUri: Uri? = null
    private var selectedMime: String = ""
    private var selectedName: String = ""
    private var selectedBytes: Long = 0L
    private var savedUri: Uri? = null
    private var savedUris: ArrayList<Uri> = arrayListOf()
    private var savedMime: String = ""
    private var savedBytes: Long = 0L
    private var busy = false

    private lateinit var statusText: TextView
    private lateinit var fileText: TextView
    private lateinit var fileSubText: TextView
    private lateinit var qualityText: TextView
    private lateinit var qualitySeek: SeekBar
    private lateinit var resolutionSpinner: Spinner
    private lateinit var compressButton: Button
    private lateinit var splitButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var shareButton: Button
    private lateinit var photoButton: Button
    private lateinit var videoButton: Button

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) acceptSelection(uri)
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) acceptSelection(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(26))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val brandRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val logo = TextView(this).apply {
            text = "SJ"
            textSize = 17f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(accent, 15)
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brandText.addView(text("STATUS JERNIH", 16f, white, true))
        brandText.addView(text("Kompres media buat WhatsApp", 12f, muted, false))
        brandRow.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        val free = TextView(this).apply {
            text = "GRATIS"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(mint)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(0xFF19332F.toInt(), 10)
        }
        brandRow.addView(free)
        content.addView(brandRow)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(21), dp(18), dp(20))
            background = rounded(surface, 22)
        }
        val eyebrow = text("STATUS LEBIH TAJAM", 11f, mint, true).apply { letterSpacing = .1f }
        hero.addView(eyebrow)
        hero.addView(text("Upload lebih jernih.\nTanpa watermark.", 26f, white, true).apply {
            setPadding(0, dp(9), 0, dp(8))
        })
        hero.addView(text("Kompres foto dan video langsung di HP. File asli kamu nggak diubah.", 14f, muted, false))
        content.addView(hero, margin(0, 22, 0, 20))

        content.addView(text("PILIH MEDIA", 12f, muted, true), margin(2, 0, 0, 10))
        val chooseRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        photoButton = button("▧  Foto", accent, white) { pickPhoto.launch(arrayOf("image/*")) }
        videoButton = button("▶  Video", card, white) { pickVideo.launch(arrayOf("video/*")) }
        chooseRow.addView(photoButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        chooseRow.addView(videoButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        content.addView(chooseRow)

        val fileCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(card, 18)
        }
        fileCard.addView(text("MEDIA DIPILIH", 10f, muted, true))
        fileText = text("Belum ada foto atau video", 15f, white, true).apply { setPadding(0, dp(8), 0, dp(4)) }
        fileSubText = text("Pilih media dari galeri untuk mulai.", 12f, muted, false)
        fileCard.addView(fileText)
        fileCard.addView(fileSubText)
        content.addView(fileCard, margin(0, 12, 0, 18))

        val imageSettings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(card, 18)
        }
        imageSettings.addView(text("KUALITAS FOTO", 12f, white, true))
        qualityText = text("80% · Seimbang", 13f, mint, true).apply { setPadding(0, dp(9), 0, 0) }
        imageSettings.addView(qualityText)
        qualitySeek = SeekBar(this).apply {
            max = 55
            progress = 35
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(white)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progressValue: Int, fromUser: Boolean) {
                    val q = progressValue + 40
                    qualityText.text = "$q% · ${when { q >= 90 -> "Kualitas tinggi"; q >= 75 -> "Seimbang"; else -> "Ukuran kecil" }}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        imageSettings.addView(qualitySeek, margin(0, 0, 0, 0))
        imageSettings.addView(text("Resolusi foto dibatasi sampai 1920 px agar lebih ringan.", 11f, muted, false))
        content.addView(imageSettings, margin(0, 0, 0, 12))

        val videoSettings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(card, 18)
        }
        videoSettings.addView(text("RESOLUSI VIDEO", 12f, white, true))
        resolutionSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Hemat · 480p", "HD · 720p (disarankan)", "Full HD · 1080p"))
            setSelection(1)
        }
        videoSettings.addView(resolutionSpinner, margin(0, 7, 0, 4))
        videoSettings.addView(text("Video diproses di perangkat menggunakan encoder Android.", 11f, muted, false))
        content.addView(videoSettings, margin(0, 0, 0, 17))

        compressButton = button("Kompres sekarang  →", accent, white) { startCompression() }
        content.addView(compressButton, LinearLayout.LayoutParams(-1, dp(56)))
        splitButton = button("Potong video jadi 30 detik", card, white) { splitVideoIntoParts() }.apply { isEnabled = false; alpha = .55f }
        content.addView(splitButton, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(9) })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(mint)
            visibility = View.GONE
        }
        content.addView(progress, margin(0, 12, 0, 0))
        progressText = text("", 12f, muted, false).apply { visibility = View.GONE }
        content.addView(progressText, margin(0, 7, 0, 0))

        val resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(surface, 18)
        }
        resultCard.addView(text("HASIL KOMPRESI", 12f, white, true))
        statusText = text("Hasil kompresi akan muncul di sini.", 13f, muted, false).apply { setPadding(0, dp(8), 0, dp(12)) }
        resultCard.addView(statusText)
        shareButton = button("Bagikan hasil", 0xFF24382F.toInt(), mint) { shareSaved() }.apply { isEnabled = false; alpha = .55f }
        resultCard.addView(shareButton, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(resultCard, margin(0, 18, 0, 0))

        content.addView(text("Privasi: file diproses lokal. Tidak ada login, iklan, watermark, atau paket premium.", 11f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(20), dp(8), 0)
        })
    }

    private fun acceptSelection(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        selectedUri = uri
        selectedMime = contentResolver.getType(uri) ?: ""
        selectedName = queryName(uri) ?: "media dipilih"
        selectedBytes = querySize(uri)
        fileText.text = selectedName
        fileSubText.text = "${mimeLabel(selectedMime)} · ${prettyBytes(selectedBytes)}"
        val isVideo = selectedMime.startsWith("video/") || selectedName.lowercase().endsWith(".mp4") || selectedName.lowercase().endsWith(".mov")
        qualitySeek.isEnabled = !isVideo
        resolutionSpinner.isEnabled = isVideo
        splitButton.isEnabled = isVideo
        splitButton.alpha = if (isVideo) 1f else .55f
        videoButton.alpha = if (isVideo) 1f else 0.88f
        statusText.text = "Media siap diproses."
        shareButton.isEnabled = savedUri != null || savedUris.isNotEmpty()
        shareButton.alpha = if (savedUri != null || savedUris.isNotEmpty()) 1f else .55f
    }

    private fun startCompression() {
        val uri = selectedUri
        if (uri == null) {
            toast("Pilih foto atau video dulu, bro.")
            return
        }
        if (busy) return
        val isVideo = selectedMime.startsWith("video/") || selectedName.lowercase().endsWith(".mp4") || selectedName.lowercase().endsWith(".mov")
        if (isVideo) compressVideo(uri) else compressPhoto(uri)
    }

    private fun compressPhoto(uri: Uri) {
        setBusy(true, "Menyiapkan foto…")
        val quality = qualitySeek.progress + 40
        io.execute {
            var sourceBitmap: Bitmap? = null
            var outputBitmap: Bitmap? = null
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    ?: throw IllegalStateException("File foto tidak bisa dibaca.")
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("Format foto tidak didukung.")
                var sample = 1
                while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2560) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                sourceBitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw IllegalStateException("Gagal membaca foto.")
                val maxSide = max(sourceBitmap!!.width, sourceBitmap!!.height)
                outputBitmap = if (maxSide > 1920) {
                    val scale = 1920f / maxSide
                    Bitmap.createScaledBitmap(sourceBitmap!!, (sourceBitmap!!.width * scale).roundToInt().coerceAtLeast(1), (sourceBitmap!!.height * scale).roundToInt().coerceAtLeast(1), true)
                } else sourceBitmap

                // Respect common EXIF orientation values from camera photos.
                val orientation = try {
                    contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                        ?: ExifInterface.ORIENTATION_NORMAL
                } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val transform = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> transform.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> transform.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> transform.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> transform.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> transform.postScale(1f, -1f)
                }
                if (!transform.isIdentity && outputBitmap != null) {
                    val rotated = Bitmap.createBitmap(outputBitmap!!, 0, 0, outputBitmap!!.width, outputBitmap!!.height, transform, true)
                    if (rotated !== outputBitmap && outputBitmap !== sourceBitmap) outputBitmap?.recycle()
                    outputBitmap = rotated
                }

                val displayName = "StatusJernih_${System.currentTimeMillis()}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/StatusJernih")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val outUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gagal membuat file hasil.")
                try {
                    contentResolver.openOutputStream(outUri)?.use { stream ->
                        if (!outputBitmap!!.compress(Bitmap.CompressFormat.JPEG, quality, stream)) throw IllegalStateException("Kompresi foto gagal.")
                    } ?: throw IllegalStateException("Gagal menyimpan foto.")
                    contentResolver.update(outUri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                } catch (e: Exception) {
                    contentResolver.delete(outUri, null, null)
                    throw e
                }
                val outSize = querySize(outUri)
                runOnUiThread {
                    savedUri = outUri
                    savedUris = arrayListOf(outUri)
                    savedMime = "image/jpeg"
                    savedBytes = outSize
                    val diff = if (selectedBytes > 0) (100 - (outSize * 100 / selectedBytes)).toInt() else 0
                    statusText.text = "Selesai · ${prettyBytes(outSize)}\n$diff% lebih kecil dari sumber (perkiraan).\nDisimpan di Pictures/StatusJernih."
                    setBusy(false, "Foto berhasil dikompres.")
                    shareButton.isEnabled = true
                    shareButton.alpha = 1f
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false, "Gagal: ${e.message ?: "format belum didukung"}")
                    toast("Kompresi gagal. Coba file lain.")
                }
            } finally {
                if (outputBitmap !== sourceBitmap) outputBitmap?.recycle()
                sourceBitmap?.recycle()
            }
        }
    }

    private fun compressVideo(uri: Uri) {
        setBusy(true, "Menyiapkan video…")
        val resOption = resolutionSpinner.selectedItemPosition
        val maxDimension = when (resOption) { 0 -> 480; 1 -> 720; else -> 1080 }
        val bitrate = when (resOption) { 0 -> 700_000L; 1 -> 1_600_000L; else -> 3_000_000L }
        val outputFile = File(cacheDir, "status_jernih_${System.currentTimeMillis()}.mp4")
        try {
            val strategy = DefaultVideoStrategy.Builder()
                .addResizer(AtMostResizer(maxDimension))
                .bitRate(bitrate)
                .frameRate(30)
                .keyFrameInterval(3f)
                .build()
            val audioStrategy = DefaultAudioStrategy.builder().build()
            Transcoder.into(outputFile.absolutePath)
                .addDataSource(this, uri)
                .setVideoTrackStrategy(strategy)
                .setAudioTrackStrategy(audioStrategy)
                .setListener(object : TranscoderListener {
                    override fun onTranscodeProgress(progressValue: Double) {
                        runOnUiThread {
                            progress.progress = (progressValue * 100).toInt().coerceIn(0, 100)
                            progressText.text = "Mengompres video… ${progress.progress}%"
                        }
                    }
                    override fun onTranscodeCompleted(successCode: Int) {
                        io.execute {
                            try {
                                val values = ContentValues().apply {
                                    put(MediaStore.Video.Media.DISPLAY_NAME, "StatusJernih_${System.currentTimeMillis()}.mp4")
                                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StatusJernih")
                                    put(MediaStore.Video.Media.IS_PENDING, 1)
                                }
                                val outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                    ?: throw IllegalStateException("Gagal membuat file video.")
                                try {
                                    contentResolver.openOutputStream(outUri)?.use { out -> outputFile.inputStream().use { it.copyTo(out) } }
                                        ?: throw IllegalStateException("Gagal menyimpan hasil video.")
                                    contentResolver.update(outUri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                                } catch (e: Exception) {
                                    contentResolver.delete(outUri, null, null)
                                    throw e
                                }
                                val newSize = querySize(outUri)
                                runOnUiThread {
                                    savedUri = outUri
                                    savedUris = arrayListOf(outUri)
                                    savedMime = "video/mp4"
                                    savedBytes = newSize
                                    val percent = if (selectedBytes > 0) (100 - newSize * 100 / selectedBytes).toInt() else 0
                                    statusText.text = "Selesai · ${prettyBytes(newSize)}\n$percent% lebih kecil dari sumber (perkiraan).\nDisimpan di Movies/StatusJernih."
                                    setBusy(false, "Video berhasil dikompres. Membuka WhatsApp…")
                                    shareButton.isEnabled = true
                                    shareButton.alpha = 1f
                                    // Version 2.0: automatically open WhatsApp with the compressed video attached.
                                    // Android/WhatsApp still requires the user to choose the self-chat and tap Send.
                                    shareVideoToWhatsApp()
                                }
                            } catch (e: Exception) {
                                runOnUiThread { setBusy(false, "Gagal menyimpan: ${e.message}") }
                            } finally {
                                outputFile.delete()
                            }
                        }
                    }
                    override fun onTranscodeCanceled() {
                        outputFile.delete()
                        runOnUiThread { setBusy(false, "Kompresi dibatalkan.") }
                    }
                    override fun onTranscodeFailed(exception: Throwable) {
                        outputFile.delete()
                        runOnUiThread { setBusy(false, "Format video ini belum cocok di perangkat."); toast(exception.message ?: "Kompresi gagal.") }
                    }
                }).transcode()
        } catch (e: Exception) {
            outputFile.delete()
            setBusy(false, "Gagal memulai kompresi: ${e.message ?: "cek file"}")
        }
    }

    private fun shareVideoToWhatsApp() {
        val uri = savedUri ?: run {
            toast("Hasil video belum tersedia.")
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newUri(contentResolver, "Video Status Jernih", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage("com.whatsapp")
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            toast("WhatsApp tidak ditemukan. Tekan Bagikan hasil untuk memilih aplikasi lain.")
        }
    }

    private fun shareSaved() {
        val uris = if (savedUris.isNotEmpty()) savedUris else listOfNotNull(savedUri)
        if (uris.isEmpty()) { toast("Belum ada hasil untuk dibagikan."); return }
        val type = if (savedMime.startsWith("video/")) "video/mp4" else "image/jpeg"
        val intent = if (uris.size > 1) Intent(Intent.ACTION_SEND_MULTIPLE) else Intent(Intent.ACTION_SEND)
        intent.apply {
            this.type = type
            if (uris.size > 1) putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris)) else putExtra(Intent.EXTRA_STREAM, uris.first())
            clipData = android.content.ClipData.newUri(contentResolver, "Hasil Status Jernih", uris.first()).apply {
                for (uri in uris.drop(1)) addItem(android.content.ClipData.Item(uri))
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, if (uris.size > 1) "Bagikan ${uris.size} bagian video" else "Bagikan hasil kompresi"))
        } catch (_: Exception) {
            toast("Aplikasi untuk berbagi belum tersedia.")
        }
    }

    private fun splitVideoIntoParts() {
        val uri = selectedUri ?: run { toast("Pilih video dulu."); return }
        val isVideo = selectedMime.startsWith("video/") || selectedName.lowercase().endsWith(".mp4") || selectedName.lowercase().endsWith(".mov")
        if (!isVideo) { toast("Fitur ini khusus video."); return }
        if (busy) return
        val retriever = MediaMetadataRetriever()
        val durationMs: Long
        try {
            retriever.setDataSource(this, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            toast("Durasi video tidak bisa dibaca.")
            return
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
        if (durationMs <= 30_000L) {
            toast("Video ini sudah 30 detik atau kurang, bro.")
            return
        }
        val totalParts = ((durationMs + 29_999L) / 30_000L).toInt()
        val maxDimension = when (resolutionSpinner.selectedItemPosition) { 0 -> 480; 1 -> 720; else -> 1080 }
        val bitrate = when (resolutionSpinner.selectedItemPosition) { 0 -> 700_000L; 1 -> 1_600_000L; else -> 3_000_000L }
        val parts = arrayListOf<Uri>()
        var totalSize = 0L
        setBusy(true, "Menyiapkan $totalParts bagian video…")
        savedUris = arrayListOf()
        savedUri = null

        fun transcodePart(index: Int) {
            if (index >= totalParts) {
                runOnUiThread {
                    savedUris = ArrayList(parts)
                    savedUri = parts.lastOrNull()
                    savedMime = "video/mp4"
                    savedBytes = totalSize
                    statusText.text = "$totalParts bagian video selesai.\nTotal ${prettyBytes(totalSize)}.\nDisimpan di Movies/StatusJernih."
                    setBusy(false, "Video selesai dipotong jadi $totalParts bagian.")
                    shareButton.isEnabled = true
                    shareButton.alpha = 1f
                }
                return
            }
            val startUs = index * 30_000_000L
            val endUs = minOf((index + 1) * 30_000_000L, durationMs * 1000L)
            val out = File(cacheDir, "split_${System.currentTimeMillis()}_$index.mp4")
            try {
                val source = ClipDataSource(UriDataSource(this, uri), startUs, endUs)
                val videoStrategy = DefaultVideoStrategy.Builder()
                    .addResizer(AtMostResizer(maxDimension))
                    .bitRate(bitrate)
                    .frameRate(30)
                    .keyFrameInterval(3f)
                    .build()
                Transcoder.into(out.absolutePath)
                    .addDataSource(source)
                    .setVideoTrackStrategy(videoStrategy)
                    .setAudioTrackStrategy(DefaultAudioStrategy.builder().build())
                    .setListener(object : TranscoderListener {
                        override fun onTranscodeProgress(progressValue: Double) {
                            runOnUiThread {
                                val overall = (((index + progressValue) / totalParts) * 100).toInt().coerceIn(0, 100)
                                progress.progress = overall
                                progressText.text = "Bagian ${index + 1}/$totalParts · $overall%"
                            }
                        }
                        override fun onTranscodeCompleted(successCode: Int) {
                            io.execute {
                                try {
                                    val outUri = saveVideoFile(out, "StatusJernih_Bagian_${(index + 1).toString().padStart(2, '0')}.mp4")
                                    val size = querySize(outUri)
                                    parts.add(outUri)
                                    totalSize += size
                                    out.delete()
                                    transcodePart(index + 1)
                                } catch (e: Exception) {
                                    out.delete()
                                    runOnUiThread { setBusy(false, "Gagal menyimpan bagian ${index + 1}: ${e.message}") }
                                }
                            }
                        }
                        override fun onTranscodeCanceled() {
                            out.delete()
                            runOnUiThread { setBusy(false, "Pemotongan dibatalkan.") }
                        }
                        override fun onTranscodeFailed(exception: Throwable) {
                            out.delete()
                            runOnUiThread { setBusy(false, "Gagal memproses bagian ${index + 1}."); toast(exception.message ?: "Format video belum cocok.") }
                        }
                    }).transcode()
            } catch (e: Exception) {
                out.delete()
                runOnUiThread { setBusy(false, "Gagal memulai pemotongan: ${e.message}") }
            }
        }
        transcodePart(0)
    }

    private fun saveVideoFile(file: File, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StatusJernih")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Gagal membuat file video.")
        try {
            contentResolver.openOutputStream(outUri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: throw IllegalStateException("Gagal menulis video.")
            contentResolver.update(outUri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            contentResolver.delete(outUri, null, null)
            throw e
        }
        return outUri
    }

    private fun setBusy(value: Boolean, message: String) {
        busy = value
        compressButton.isEnabled = !value
        compressButton.alpha = if (value) .6f else 1f
        photoButton.isEnabled = !value
        videoButton.isEnabled = !value
        splitButton.isEnabled = !value && (selectedMime.startsWith("video/") || selectedName.lowercase().endsWith(".mp4") || selectedName.lowercase().endsWith(".mov"))
        progress.visibility = if (value) View.VISIBLE else View.GONE
        progressText.visibility = if (value) View.VISIBLE else View.GONE
        if (value) progress.progress = 0
        progressText.text = message
        if (!value) statusText.text = if (message.startsWith("Gagal")) message else statusText.text
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }
    } catch (_: Exception) { null }

    private fun querySize(uri: Uri): Long = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
        } ?: 0L
    } catch (_: Exception) { 0L }

    private fun mimeLabel(mime: String): String = when {
        mime.startsWith("video/") -> "Video"
        mime.startsWith("image/") -> "Foto"
        else -> "Media"
    }

    private fun prettyBytes(bytes: Long): String {
        if (bytes <= 0) return "ukuran tidak diketahui"
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb < 1) "${(bytes / 1024.0).roundToInt()} KB" else "${DecimalFormat("0.##").format(mb)} MB"
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun button(label: String, color: Int, textColor: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(textColor)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        background = rounded(color, 16)
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { action() }
        stateListAnimator = null
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun margin(left: Int, top: Int, right: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(dp(left), dp(top), dp(right), dp(bottom))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}

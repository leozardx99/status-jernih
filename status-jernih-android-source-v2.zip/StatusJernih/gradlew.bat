@echo off
setlocal
set VERSION=8.9
set GH=%USERPROFILE%\.gradle
if defined GRADLE_USER_HOME set GH=%GRADLE_USER_HOME%
set BASE=%GH%\wrapper\dists\status-jernih\gradle-%VERSION%
set BIN=%BASE%\gradle-%VERSION%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Downloading Gradle %VERSION% (one-time setup)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle.zip'; Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'; Remove-Item '%BASE%\gradle.zip'"
  if errorlevel 1 exit /b 1
)
call "%BIN%" %*
endlocal

# Status Jernih — Android

Alternatif gratis untuk menyiapkan foto dan video sebelum dipasang ke Status WhatsApp. Aplikasi ini dibuat dari nol dan tidak menggunakan nama, logo, atau kode milik PureStatus.

## Fitur versi 1.0

- Kompres foto ke JPEG dengan pengaturan kualitas 40–95% dan batas ukuran sisi terpanjang 1920 px.
- Kompres video ke resolusi maksimum 480p, 720p, atau 1080p.
- Pecah video panjang menjadi bagian maksimal sekitar 30 detik (pemotongan dilakukan dengan transcoding).
- Simpan hasil ke `Pictures/StatusJernih` atau `Movies/StatusJernih`.
- Bagikan hasil lewat Android Share Sheet, termasuk WhatsApp jika tersedia.
- Tanpa akun, iklan, watermark, atau langganan. Pemrosesan dilakukan di perangkat; tidak ada layanan unggah ke server dalam kode aplikasi.

## Cara membangun APK

Build tool Android tidak tersedia di lingkungan tempat source ini dibuat, jadi berkas APK belum bisa dikompilasi dan diuji di sini. Source project ini disiapkan untuk Android Studio.

1. Instal Android Studio pada komputer.
2. Ekstrak folder `StatusJernih.zip`.
3. Di Android Studio pilih **Open**, lalu pilih folder `StatusJernih` (folder yang berisi `settings.gradle.kts`).
4. Izinkan Gradle melakukan sync dan mengunduh Android SDK/dependency bila diminta. Gunakan JDK 17 atau versi yang disarankan Android Studio.
5. Dari menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**, tunggu sampai proses build selesai.
6. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android dan instal. Android mungkin meminta izin **Install unknown apps** untuk aplikasi yang dipakai membuka APK.

## Catatan kompatibilitas

- `minSdk` 29 (Android 10 atau lebih baru).
- Kompresi video memakai Android MediaCodec melalui pustaka open-source Transcoder berlisensi Apache-2.0.
- Kompatibilitas format video bisa berbeda tergantung codec yang didukung oleh perangkat. Jika file gagal diproses, coba video MP4/H.264.
- Video dipotong pada batas waktu sekitar 30 detik; batas keyframe dan karakteristik file sumber dapat memengaruhi batas yang terlihat.
- Kompresi tidak bisa mengembalikan detail yang sudah hilang dari media asli dan WhatsApp masih dapat melakukan kompresi lagi saat upload.

## Teknologi

- Kotlin + Android SDK
- Android MediaStore dan Storage Access Framework
- `io.deepmedia.community:transcoder-android:0.11.2`
- `androidx.exifinterface:exifinterface:1.3.7`

### Alternatif build tanpa memasang Android Studio lokal

Project ini juga menyertakan workflow GitHub Actions di `.github/workflows/build-apk.yml`. Jika project diunggah ke repo GitHub milikmu, workflow dapat membangun `app-debug.apk` dan menampilkannya sebagai artifact di halaman run Actions. Workflow membutuhkan akses internet di runner GitHub untuk mengambil Gradle dan dependensi.
